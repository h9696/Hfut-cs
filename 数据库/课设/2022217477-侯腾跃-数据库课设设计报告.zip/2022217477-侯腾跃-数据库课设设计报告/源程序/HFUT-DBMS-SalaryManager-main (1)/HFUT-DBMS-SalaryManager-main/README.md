用的比较老的技术栈做的，功能简单，没用Maven管理
JSP + Html + CSS + JS + Tomcat
