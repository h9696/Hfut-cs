开发语言：Java

框架：springboot

JDK版本：JDK1.8

服务器：tomcat7

数据库：mysql 5.7（一定要5.7版本）

数据库工具：Navicat11

开发软件：eclipse/myeclipse/idea

Maven包：Maven3.3.9

浏览器：谷歌浏览器



后台路径地址：localhost:8080/springbootl3663/admin/dist/index.html
前台路径地址：localhost:8080/springbootl3663/front/dist/index.html



管理员账号：admin

管理员密码：admin